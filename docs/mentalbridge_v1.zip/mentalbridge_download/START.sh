#!/bin/bash
echo "Starting MentalBridge..."
OLLAMA_ORIGINS="*" ollama serve &
sleep 3
python3 -m http.server 8080 &
sleep 1
open http://localhost:8080
echo "MentalBridge is running!"
