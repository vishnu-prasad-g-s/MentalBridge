MENTALBRIDGE — Setup Instructions
==================================
Requirements:
1. Install Ollama from https://ollama.com
2. Run once: ollama pull gemma4:e2b

To start MentalBridge:
   Run: bash START.sh
   Then open: http://localhost:8080
